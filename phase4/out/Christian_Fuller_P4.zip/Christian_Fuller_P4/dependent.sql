INSERT INTO dependent VALUES('987-65-4324', 'Alice', 12);
INSERT INTO dependent VALUES('987-65-4324', 'Bob', 10);
INSERT INTO dependent VALUES('987-65-4325', 'Alice', 5);
INSERT INTO dependent VALUES('987-65-4325', 'Bob', 7);
INSERT INTO dependent VALUES('987-65-4325', 'Cindy', 11);
INSERT INTO dependent VALUES('987-65-4329', 'Alan', 6);
INSERT INTO dependent VALUES('987-64-4321', 'Betty', 2);
commit;